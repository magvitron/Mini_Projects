zlookup = {'z1', 'z2', 'z3'};
T={1,1,2};
T3 = T{:,3};
[tf, idx] = ismember(T3, [60, 40, 30]);
out = cell(length(tf),1);
out(tf) = zlookup(idx(tf));
out(~tf) = sprintfc('%g', T3(~tf));
T{:,3} = out;
disp(T);
